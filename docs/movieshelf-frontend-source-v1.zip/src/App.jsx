import MovieShelf from "./7 - movieshelf/MovieShelf.jsx";

export default function App() {
  return <MovieShelf />;
}
